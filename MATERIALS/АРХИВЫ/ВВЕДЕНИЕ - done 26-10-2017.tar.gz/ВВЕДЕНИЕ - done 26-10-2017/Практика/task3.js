let arr = ["World", "Tom", "Bob"];
arr.forEach((value) => console.log(`Hello ${value}!`));
