import { foo } from './moduleSquare.js';

foo(3,2);
