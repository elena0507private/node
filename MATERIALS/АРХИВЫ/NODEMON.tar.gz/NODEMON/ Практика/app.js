console.log("Hello LOL!");
