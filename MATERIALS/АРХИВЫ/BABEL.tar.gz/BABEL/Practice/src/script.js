let myPeopleGo = "Go gaway..it is later";
let myPeopleGo2 = "Go gaway..please ";
