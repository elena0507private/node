const greeting = require("./greeting");

global.digit = "4";
greeting.getSqrt();

